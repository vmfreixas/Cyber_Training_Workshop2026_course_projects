

                     SUMMARY OF  INDO CALCULATION

                                                       MOPAC v23.2.5 Linux
                                                       Wed Jul 15 23:16:14 2026

           Empirical Formula: C6 H6  =    12 atoms

 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5




     1SCF WAS SPECIFIED, SO BFGS WAS NOT USED                 
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =     -22261.35622 KCAL/MOL =  -93141.51444 KJ/MOL
          DIPOLE                  =          0.00023 DEBYE   POINT GROUP:  D6h 
          NO. OF FILLED LEVELS    =         15
          CONFIGURATION INTERACTION WAS USED
          IONIZATION POTENTIAL    =          8.974142 EV
          HOMO LUMO ENERGIES (EV) =         -8.974  0.851
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.64 SQUARE ANGSTROMS
          COSMO VOLUME            =        106.35 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    11    H     8     4.96195
            H    12    H     9     4.29714
            C     4    C     2     0.00023
          SCF CALCULATIONS        =          1
          WALL-CLOCK TIME         =      0.102 SECONDS
          COMPUTATION TIME        =      0.041 SECONDS


          FINAL GEOMETRY OBTAINED
 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5


  C     6.28690000 +1   6.81165000 +1   7.50000000 +1
  C     6.29720000 +1   8.20645000 +1   7.50010000 +1
  C     7.48970000 +1   6.10525000 +1   7.50000000 +1
  C     7.51040000 +1   8.89485000 +1   7.49990000 +1
  C     8.70280000 +1   6.79375000 +1   7.50000000 +1
  C     8.71310000 +1   8.18845000 +1   7.50000000 +1
  H     5.34230000 +1   6.27565000 +1   7.50000000 +1
  H     5.36070000 +1   8.75645000 +1   7.50010000 +1
  H     7.48160000 +1   5.01915000 +1   7.49990000 +1
  H     7.51840000 +1   9.98085000 +1   7.50000000 +1
  H     9.63940000 +1   6.24375000 +1   7.50010000 +1
  H     9.65770000 +1   8.72455000 +1   7.50000000 +1

