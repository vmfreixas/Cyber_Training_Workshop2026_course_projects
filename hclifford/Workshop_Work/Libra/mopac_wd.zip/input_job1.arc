

                     SUMMARY OF  INDO CALCULATION

                                                       MOPAC v23.2.5 Linux
                                                       Wed Jul 15 23:16:14 2026

           Empirical Formula: C6 H6  =    12 atoms

 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5




     1SCF WAS SPECIFIED, SO BFGS WAS NOT USED                 
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =     -22256.11931 KCAL/MOL =  -93119.60320 KJ/MOL
          DIPOLE                  =          0.03866 DEBYE   POINT GROUP:  D6h 
          NO. OF FILLED LEVELS    =         15
          CONFIGURATION INTERACTION WAS USED
          IONIZATION POTENTIAL    =          8.953946 EV
          HOMO LUMO ENERGIES (EV) =         -8.954  0.830
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        118.78 SQUARE ANGSTROMS
          COSMO VOLUME            =        106.22 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    10    H     9     4.97104
            H    12    H     8     4.31557
            H     7    H    11     0.02820
          SCF CALCULATIONS        =          1
          WALL-CLOCK TIME         =      0.031 SECONDS
          COMPUTATION TIME        =      0.015 SECONDS


          FINAL GEOMETRY OBTAINED
 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5


  C     6.28849476 +1   6.81091488 +1   7.49920723 +1
  C     6.29646359 +1   8.20701844 +1   7.49882593 +1
  C     7.48680780 +1   6.10513504 +1   7.49753652 +1
  C     7.51309495 +1   8.89300802 +1   7.50142207 +1
  C     8.70522552 +1   6.79348501 +1   7.50049709 +1
  C     8.71264981 +1   8.18832546 +1   7.50304957 +1
  H     5.34030062 +1   6.27164199 +1   7.50705433 +1
  H     5.34652335 +1   8.74895437 +1   7.49415425 +1
  H     7.47052590 +1   5.02827389 +1   7.49254246 +1
  H     7.51495290 +1   9.99911887 +1   7.49490378 +1
  H     9.63437490 +1   6.25861937 +1   7.49482995 +1
  H     9.66200662 +1   8.72373928 +1   7.51019943 +1

