

                     SUMMARY OF  INDO CALCULATION

                                                       MOPAC v23.2.5 Linux
                                                       Wed Jul 15 23:16:14 2026

           Empirical Formula: C6 H6  =    12 atoms

 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5




     1SCF WAS SPECIFIED, SO BFGS WAS NOT USED                 
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =     -22249.63500 KCAL/MOL =  -93092.47285 KJ/MOL
          DIPOLE                  =          0.07356 DEBYE   POINT GROUP:  D3d 
          NO. OF FILLED LEVELS    =         15
          CONFIGURATION INTERACTION WAS USED
          IONIZATION POTENTIAL    =          8.934153 EV
          HOMO LUMO ENERGIES (EV) =         -8.934  0.808
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.00 SQUARE ANGSTROMS
          COSMO VOLUME            =        106.02 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    10    H     9     4.98041
            H    12    H     8     4.33369
            H     7    H    11     0.05577
          SCF CALCULATIONS        =          1
          WALL-CLOCK TIME         =      0.031 SECONDS
          COMPUTATION TIME        =      0.015 SECONDS


          FINAL GEOMETRY OBTAINED
 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5


  C     6.28992043 +1   6.81016047 +1   7.49843566 +1
  C     6.29561644 +1   8.20763035 +1   7.49757643 +1
  C     7.48403028 +1   6.10497634 +1   7.49512241 +1
  C     7.51567513 +1   8.89144399 +1   7.50290753 +1
  C     8.70758824 +1   6.79321620 +1   7.50097985 +1
  C     8.71234042 +1   8.18824591 +1   7.50604180 +1
  H     5.33818463 +1   6.26764718 +1   7.51391708 +1
  H     5.33279489 +1   8.74174266 +1   7.48834728 +1
  H     7.45976498 +1   5.03593261 +1   7.48534308 +1
  H     7.51166475 +1  10.01606661 +1   7.48995280 +1
  H     9.63082669 +1   6.27223813 +1   7.48968743 +1
  H     9.66641031 +1   8.72309721 +1   7.52016626 +1

