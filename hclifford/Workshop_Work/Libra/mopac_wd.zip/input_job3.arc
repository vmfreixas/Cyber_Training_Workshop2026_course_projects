

                     SUMMARY OF  INDO CALCULATION

                                                       MOPAC v23.2.5 Linux
                                                       Wed Jul 15 23:16:14 2026

           Empirical Formula: C6 H6  =    12 atoms

 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5




     1SCF WAS SPECIFIED, SO BFGS WAS NOT USED                 
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =     -22241.95623 KCAL/MOL =  -93060.34485 KJ/MOL
          DIPOLE                  =          0.10322 DEBYE   POINT GROUP:  D3h 
          NO. OF FILLED LEVELS    =         15
          CONFIGURATION INTERACTION WAS USED
          IONIZATION POTENTIAL    =          8.914452 EV
          HOMO LUMO ENERGIES (EV) =         -8.914  0.787
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.14 SQUARE ANGSTROMS
          COSMO VOLUME            =        106.52 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    10    H     9     4.98976
            H     8    H    12     4.35142
            H    11    H     7     0.08364
          SCF CALCULATIONS        =          1
          WALL-CLOCK TIME         =      0.039 SECONDS
          COMPUTATION TIME        =      0.016 SECONDS


          FINAL GEOMETRY OBTAINED
 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5


  C     6.29119161 +1   6.80936288 +1   7.49765669 +1
  C     6.29459423 +1   8.20831668 +1   7.49629548 +1
  C     7.48129556 +1   6.10481475 +1   7.49265147 +1
  C     7.51820070 +1   8.89020799 +1   7.50441475 +1
  C     8.70988596 +1   6.79297055 +1   7.50146579 +1
  C     8.71219990 +1   8.18820736 +1   7.50911335 +1
  H     5.33616113 +1   6.26368349 +1   7.52083688 +1
  H     5.31950213 +1   8.73437477 +1   7.48244554 +1
  H     7.44893350 +1   5.04178702 +1   7.47798852 +1
  H     7.50847964 +1  10.03118864 +1   7.48498321 +1
  H     9.62947791 +1   6.28457341 +1   7.48445651 +1
  H     9.67082486 +1   8.72248412 +1   7.53030875 +1

