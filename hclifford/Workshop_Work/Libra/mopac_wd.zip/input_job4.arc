

                     SUMMARY OF  INDO CALCULATION

                                                       MOPAC v23.2.5 Linux
                                                       Wed Jul 15 23:16:14 2026

           Empirical Formula: C6 H6  =    12 atoms

 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5




     1SCF WAS SPECIFIED, SO BFGS WAS NOT USED                 
     SCF FIELD WAS ACHIEVED                                   

          HEAT OF FORMATION       =     -22233.63906 KCAL/MOL =  -93025.54582 KJ/MOL
          DIPOLE                  =          0.12451 DEBYE   POINT GROUP:  D2h 
          NO. OF FILLED LEVELS    =         15
          CONFIGURATION INTERACTION WAS USED
          IONIZATION POTENTIAL    =          8.895661 EV
          HOMO LUMO ENERGIES (EV) =         -8.896  0.766
          MOLECULAR WEIGHT        =         78.1134
          COSMO AREA              =        119.45 SQUARE ANGSTROMS
          COSMO VOLUME            =        106.33 CUBIC ANGSTROMS

          MOLECULAR DIMENSIONS (Angstroms)

            Atom       Atom       Distance
            H    10    H     9     4.99838
            H    12    H     8     4.36742
            H     7    H    11     0.11093
          SCF CALCULATIONS        =          1
          WALL-CLOCK TIME         =      0.031 SECONDS
          COMPUTATION TIME        =      0.015 SECONDS


          FINAL GEOMETRY OBTAINED
 INDO C.I.=(6,3) CHARGE=0 RELSCF=0.000001 ALLVEC  WRTCONF=0.00  WRTCI=5


  C     6.29222459 +1   6.80855652 +1   7.49689892 +1
  C     6.29340491 +1   8.20905897 +1   7.49501962 +1
  C     7.47873328 +1   6.10469095 +1   7.49019684 +1
  C     7.52054481 +1   8.88943267 +1   7.50589183 +1
  C     8.71195916 +1   6.79278604 +1   7.50193731 +1
  C     8.71227134 +1   8.18821087 +1   7.51217944 +1
  H     5.33456727 +1   6.26004715 +1   7.52755214 +1
  H     5.30757354 +1   8.72697905 +1   7.47664827 +1
  H     7.43843831 +1   5.04512500 +1   7.47069579 +1
  H     7.50558357 +1  10.04304450 +1   7.48020269 +1
  H     9.63109564 +1   6.29473118 +1   7.47929355 +1
  H     9.67485559 +1   8.72181414 +1   7.54029328 +1

